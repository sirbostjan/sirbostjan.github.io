import { create } from 'zustand'

/**
 * Estado "vivo": un objeto mutable que el Canvas lee en cada frame con
 * useStore.getState().live. Mutarlo NO dispara re-renders de React.
 */
export interface Live {
  time: number
  /** 0..1 a lo largo de las estaciones de camara */
  camT: number
  /** camT ya suavizado por la camara */
  camSmooth: number
  /** 0..1 progreso total de scroll */
  progress: number
  velocity: number
  /** puntero normalizado -1..1 (y hacia arriba) */
  px: number
  py: number
  /** puntero en uv 0..1 (y hacia arriba) */
  mx: number
  my: number
  /** impulso de clic, decae a 0 */
  pulse: number
  /** energia suavizada de hover 0..1 */
  energy: number
  /** ondas del fondo: x, y (uv), tiempo de inicio, fuerza */
  ripples: Float32Array
  rippleIndex: number
}

export type Quality = 'high' | 'low'

interface State {
  live: Live
  section: number
  hover: boolean
  inspect: boolean
  ready: boolean
  quality: Quality
  turbulence: number
  viscosity: number
  setSection: (n: number) => void
  setHover: (h: boolean) => void
  setInspect: (i: boolean) => void
  setReady: () => void
  setQuality: (q: Quality) => void
  setTurbulence: (n: number) => void
  setViscosity: (n: number) => void
  addRipple: (x: number, y: number, strength?: number) => void
  pulse: (amount?: number) => void
}

const detectQuality = (): Quality =>
  typeof window !== 'undefined' &&
  (window.matchMedia('(pointer: coarse)').matches || window.innerWidth < 768)
    ? 'low'
    : 'high'

export const MAX_RIPPLES = 4

export const useStore = create<State>((set, get) => ({
  live: {
    time: 0,
    camT: 0,
    camSmooth: 0,
    progress: 0,
    velocity: 0,
    px: 0,
    py: 0,
    mx: 0.5,
    my: 0.5,
    pulse: 0,
    energy: 0,
    ripples: new Float32Array(MAX_RIPPLES * 4).fill(-100),
    rippleIndex: 0,
  },
  section: 0,
  hover: false,
  inspect: false,
  ready: false,
  quality: detectQuality(),
  turbulence: 0.5,
  viscosity: 0.5,
  setSection: (section) => get().section !== section && set({ section }),
  setHover: (hover) => get().hover !== hover && set({ hover }),
  setInspect: (inspect) => set({ inspect }),
  setReady: () => set({ ready: true }),
  setQuality: (quality) => get().quality !== quality && set({ quality }),
  setTurbulence: (turbulence) => set({ turbulence }),
  setViscosity: (viscosity) => set({ viscosity }),
  addRipple: (x, y, strength = 1) => {
    const l = get().live
    const i = l.rippleIndex * 4
    l.ripples[i] = x
    l.ripples[i + 1] = y
    l.ripples[i + 2] = l.time
    l.ripples[i + 3] = strength
    l.rippleIndex = (l.rippleIndex + 1) % MAX_RIPPLES
  },
  pulse: (amount = 1) => {
    const l = get().live
    l.pulse = Math.min(1.5, l.pulse + amount)
  },
}))

/** Acceso directo al estado vivo (misma referencia durante toda la sesion). */
export const live = useStore.getState().live
