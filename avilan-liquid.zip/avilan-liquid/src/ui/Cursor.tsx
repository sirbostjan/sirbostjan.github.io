import { useEffect, useRef } from 'react'
import gsap from 'gsap'
import { useStore } from '../store/useStore'

/** Gota que sigue al cursor con retardo viscoso y se hincha sobre elementos interactivos. */
export function Cursor() {
  const ring = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const el = ring.current
    if (!el || !window.matchMedia('(pointer: fine)').matches) return
    gsap.set(el, { xPercent: -50, yPercent: -50, opacity: 0 })
    const x = gsap.quickTo(el, 'x', { duration: 0.55, ease: 'power3.out' })
    const y = gsap.quickTo(el, 'y', { duration: 0.55, ease: 'power3.out' })
    let shown = false
    const move = (e: PointerEvent) => {
      x(e.clientX)
      y(e.clientY)
      if (!shown) {
        shown = true
        gsap.to(el, { opacity: 1, duration: 0.4 })
      }
    }
    const down = () => gsap.fromTo(el, { scale: 0.6 }, { scale: useStore.getState().hover ? 2.2 : 1, duration: 0.9, ease: 'elastic.out(1, 0.35)' })
    window.addEventListener('pointermove', move, { passive: true })
    window.addEventListener('pointerdown', down, { passive: true })
    const unsubscribe = useStore.subscribe((state, prev) => {
      if (state.hover === prev.hover) return
      gsap.to(el, {
        scale: state.hover ? 2.2 : 1,
        borderRadius: state.hover ? '42% 58% 55% 45% / 55% 42% 58% 45%' : '50%',
        duration: 0.7,
        ease: 'elastic.out(1, 0.45)',
      })
    })
    return () => {
      unsubscribe()
      window.removeEventListener('pointermove', move)
      window.removeEventListener('pointerdown', down)
    }
  }, [])

  return (
    <div
      ref={ring}
      aria-hidden
      className="pointer-events-none fixed left-0 top-0 z-50 hidden h-9 w-9 rounded-full border border-white opacity-0 mix-blend-difference [@media(pointer:fine)]:block"
    />
  )
}
