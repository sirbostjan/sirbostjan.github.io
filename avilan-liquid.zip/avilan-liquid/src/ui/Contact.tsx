import { useEffect, useRef } from 'react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import { CONTACT, PROFILE } from '../content'
import { scrollToStation } from '../hooks/useSmoothScroll'
import { SplitText } from './SplitText'

export function Contact() {
  const root = useRef<HTMLElement>(null)

  useEffect(() => {
    if (!root.current) return
    const ctx = gsap.context(() => {
      const tl = gsap.timeline({ paused: true })
      tl.fromTo(
        '.char',
        { yPercent: 110, scaleY: 2, opacity: 0, filter: 'blur(14px)' },
        { yPercent: 0, scaleY: 1, opacity: 1, filter: 'blur(0px)', duration: 1.3, ease: 'expo.out', stagger: 0.022 },
      )
      tl.fromTo('.rv', { y: 40, opacity: 0, filter: 'blur(12px)' }, { y: 0, opacity: 1, filter: 'blur(0px)', duration: 1.1, ease: 'power3.out', stagger: 0.1 }, 0.3)
      ScrollTrigger.create({
        trigger: root.current,
        start: 'top 40%',
        onEnter: () => tl.timeScale(1).play(),
        onLeaveBack: () => tl.timeScale(2.2).reverse(),
      })
    }, root)
    return () => ctx.revert()
  }, [])

  return (
    <section id="contact" ref={root} className="relative flex h-[100svh] min-h-[560px] flex-col items-center justify-center px-5 text-center">
      <p className="rv mb-6 text-xs uppercase tracking-[0.4em] text-white/70">Contacto</p>
      <h2 className="max-w-4xl font-display text-[clamp(1.9rem,5.2vw,5rem)] font-extrabold uppercase leading-[0.98] tracking-[-0.02em]">
        <SplitText text="Hagamos algo que se sienta vivo." />
      </h2>
      <p className="rv mt-7 max-w-md text-sm leading-relaxed text-white/80 md:text-base">
        Disponible para proyectos de animación, automatización y experiencias 3D interactivas. {PROFILE.location}.
      </p>
      <div className="rv mt-9 flex flex-wrap items-center justify-center gap-3">
        {CONTACT.email ? (
          <a data-liquid href={`mailto:${CONTACT.email}`} className="liquid-btn px-7 py-4 font-display text-xs font-semibold uppercase tracking-[0.2em]">
            {CONTACT.email}
          </a>
        ) : null}
        {CONTACT.links.map((link) => (
          <a key={link.href} data-liquid href={link.href} target="_blank" rel="noreferrer" className="liquid-btn px-6 py-3.5 text-xs uppercase tracking-[0.2em]">
            {link.label}
          </a>
        ))}
        <button data-liquid onClick={() => scrollToStation('hero')} className="liquid-btn px-6 py-3.5 text-xs uppercase tracking-[0.2em]">
          Volver al inicio
          <span aria-hidden>↑</span>
        </button>
      </div>
      <footer className="absolute inset-x-0 bottom-6 flex justify-between px-5 text-[0.6rem] uppercase tracking-[0.3em] text-white/45 md:px-10">
        <span>
          © {new Date().getFullYear()} {PROFILE.name}
        </span>
        <span>{PROFILE.role}</span>
      </footer>
    </section>
  )
}
