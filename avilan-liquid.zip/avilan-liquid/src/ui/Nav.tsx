import { PROFILE, SECTIONS } from '../content'
import { scrollToStation } from '../hooks/useSmoothScroll'
import { useStore } from '../store/useStore'

export function Nav() {
  const inspect = useStore((s) => s.inspect)
  const section = useStore((s) => s.section)
  return (
    <header
      className={`fixed inset-x-0 top-0 z-30 flex items-center justify-between px-5 py-5 transition-opacity duration-700 md:px-10 md:py-7 ${
        inspect ? 'pointer-events-none opacity-0' : 'opacity-100'
      }`}
    >
      <button
        data-liquid
        onClick={() => scrollToStation('hero')}
        className="liquid-link inline-block font-display text-sm font-bold tracking-[0.2em]"
        aria-label="Volver al inicio"
      >
        {PROFILE.initials}
      </button>
      <nav className="flex items-center gap-5 text-[0.7rem] uppercase tracking-[0.22em] md:gap-9 md:text-xs">
        {SECTIONS.map((s, i) => (
          <button
            key={s.id}
            data-liquid
            onClick={() => scrollToStation(s.id)}
            className={`liquid-link hidden sm:inline-block ${section === i + 1 ? 'opacity-100' : 'opacity-60 hover:opacity-100'}`}
          >
            {s.title}
          </button>
        ))}
        <button data-liquid onClick={() => scrollToStation('contact')} className="liquid-btn px-4 py-2">
          Contacto
        </button>
      </nav>
    </header>
  )
}
