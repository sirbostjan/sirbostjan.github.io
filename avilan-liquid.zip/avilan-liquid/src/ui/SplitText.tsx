/** Parte un texto en caracteres animables conservando palabras completas por linea. */
export function SplitText({ text }: { text: string }) {
  return (
    <span aria-label={text}>
      {text.split(' ').map((word, w, words) => (
        <span key={w} aria-hidden className="inline-block whitespace-nowrap">
          {[...word].map((char, c) => (
            <span key={c} className="char">
              {char}
            </span>
          ))}
          {w < words.length - 1 ? ' ' : null}
        </span>
      ))}
    </span>
  )
}
