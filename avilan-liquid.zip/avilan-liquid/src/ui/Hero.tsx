import { useEffect, useRef } from 'react'
import gsap from 'gsap'
import { PROFILE } from '../content'
import { scrollToStation } from '../hooks/useSmoothScroll'
import { useStore } from '../store/useStore'
import { SplitText } from './SplitText'

export function Hero() {
  const root = useRef<HTMLElement>(null)
  const ready = useStore((s) => s.ready)
  const [first, ...rest] = PROFILE.name.split(' ')
  const lines = rest.length > 1 ? [`${first} ${rest.slice(0, -1).join(' ')}`, rest[rest.length - 1]] : [PROFILE.name]

  useEffect(() => {
    if (!root.current) return
    const ctx = gsap.context(() => {
      gsap.set('.char', { yPercent: 120, scaleY: 2.2, opacity: 0, filter: 'blur(18px)' })
      gsap.set('.hero-fade', { y: 30, opacity: 0, filter: 'blur(10px)' })
      if (!ready) return
      const tl = gsap.timeline({ delay: 0.9 })
      tl.to('.char', { yPercent: 0, scaleY: 1, opacity: 1, filter: 'blur(0px)', duration: 1.6, ease: 'expo.out', stagger: 0.035 })
      tl.to('.hero-fade', { y: 0, opacity: 1, filter: 'blur(0px)', duration: 1.2, ease: 'power3.out', stagger: 0.12 }, 0.5)
      // al hacer scroll el titular se disuelve hacia arriba
      gsap.to('.hero-inner', {
        yPercent: -30,
        opacity: 0,
        filter: 'blur(16px)',
        ease: 'none',
        scrollTrigger: { trigger: root.current, start: 'top top', end: '70% top', scrub: true },
      })
    }, root)
    return () => ctx.revert()
  }, [ready])

  return (
    <section id="hero" ref={root} className="relative flex h-[100svh] min-h-[560px] items-center justify-center px-5">
      <div className="hero-inner flex flex-col items-center text-center">
        <p className="hero-fade mb-6 text-[0.68rem] uppercase tracking-[0.45em] text-white/80 md:text-xs">{PROFILE.role}</p>
        <h1 className="liquid-text font-display text-[clamp(2.3rem,9.2vw,9.5rem)] font-extrabold uppercase leading-[0.92] tracking-[-0.02em]">
          {lines.map((line) => (
            <span key={line} className="block overflow-visible">
              <SplitText text={line} />
            </span>
          ))}
        </h1>
        <p className="hero-fade mt-8 max-w-md text-balance text-sm leading-relaxed text-white/90 [text-shadow:0_0_18px_#000,0_0_6px_#000] md:text-base">{PROFILE.tagline}</p>
      </div>
      <button
        data-liquid
        onClick={() => scrollToStation('animation')}
        className="hero-fade liquid-link inline-block absolute bottom-8 left-1/2 -translate-x-1/2 text-[0.62rem] uppercase tracking-[0.4em] text-white/70"
      >
        Desliza
        <span aria-hidden className="mx-auto mt-3 block h-10 w-px animate-pulse bg-gradient-to-b from-white to-transparent" />
      </button>
    </section>
  )
}
