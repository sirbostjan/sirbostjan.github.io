import { STATION_LABELS, STATION_ORDER } from '../content'
import { scrollToStation } from '../hooks/useSmoothScroll'
import { useStore } from '../store/useStore'

export function ProgressRail() {
  const section = useStore((s) => s.section)
  const inspect = useStore((s) => s.inspect)
  return (
    <aside
      className={`fixed right-5 top-1/2 z-30 hidden -translate-y-1/2 flex-col items-end gap-4 transition-opacity duration-700 md:flex md:right-10 ${
        inspect ? 'pointer-events-none opacity-0' : 'opacity-100'
      }`}
    >
      {STATION_ORDER.map((id, i) => (
        <button
          key={id}
          data-liquid
          onClick={() => scrollToStation(id)}
          aria-label={`Ir a ${STATION_LABELS[id]}`}
          aria-current={section === i}
          className="group flex items-center gap-3 py-1"
        >
          <span
            className={`text-[0.62rem] uppercase tracking-[0.25em] transition-all duration-500 ${
              'translate-x-2 opacity-0 group-hover:translate-x-0 group-hover:opacity-90'
            }`}
          >
            {STATION_LABELS[id]}
          </span>
          <span
            className={`block h-px bg-white transition-all duration-700 ${
              section === i ? 'w-10 opacity-100' : 'w-4 opacity-40 group-hover:w-7 group-hover:opacity-80'
            }`}
          />
        </button>
      ))}
    </aside>
  )
}
