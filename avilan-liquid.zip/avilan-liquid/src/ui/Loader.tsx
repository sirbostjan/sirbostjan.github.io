import { useEffect, useRef, useState } from 'react'
import gsap from 'gsap'
import { PROFILE } from '../content'
import { useStore } from '../store/useStore'

export function Loader() {
  const ready = useStore((s) => s.ready)
  const root = useRef<HTMLDivElement>(null)
  const [gone, setGone] = useState(false)

  useEffect(() => {
    if (!ready || !root.current) return
    const tween = gsap.to(root.current, {
      opacity: 0,
      filter: 'blur(24px)',
      scale: 1.08,
      duration: 1.4,
      delay: 0.35,
      ease: 'power2.inOut',
      onComplete: () => setGone(true),
    })
    return () => {
      tween.kill()
    }
  }, [ready])

  if (gone) return null
  return (
    <div ref={root} role="status" className="fixed inset-0 z-[100] grid place-items-center bg-black">
      <div className="flex flex-col items-center gap-5">
        <span className="liquid-text font-display text-xs font-semibold uppercase tracking-[0.5em]">{PROFILE.initials}</span>
        <span className="relative block h-px w-40 overflow-hidden bg-white/15">
          <span className="absolute inset-y-0 left-0 w-1/2 animate-[slide_1.2s_ease-in-out_infinite] bg-gradient-to-r from-oil-red via-oil-violet to-oil-blue" />
        </span>
        <span className="text-[0.62rem] uppercase tracking-[0.35em] text-white/50">Preparando la sustancia</span>
      </div>
      <style>{'@keyframes slide{0%{transform:translateX(-100%)}100%{transform:translateX(200%)}}'}</style>
    </div>
  )
}
