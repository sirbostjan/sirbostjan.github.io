import { useEffect, useRef } from 'react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import { SECTIONS } from '../content'
import { useStore } from '../store/useStore'
import { SplitText } from './SplitText'

type SectionData = (typeof SECTIONS)[number]

export function Section({ data }: { data: SectionData }) {
  const root = useRef<HTMLElement>(null)
  const setInspect = useStore((s) => s.setInspect)

  useEffect(() => {
    if (!root.current) return
    const ctx = gsap.context(() => {
      const tl = gsap.timeline({ paused: true })
      tl.fromTo(
        '.char',
        { yPercent: 110, scaleY: 2, opacity: 0, filter: 'blur(14px)' },
        { yPercent: 0, scaleY: 1, opacity: 1, filter: 'blur(0px)', duration: 1.3, ease: 'expo.out', stagger: 0.03 },
      )
      tl.fromTo(
        '.rv',
        { y: 44, opacity: 0, filter: 'blur(12px)' },
        { y: 0, opacity: 1, filter: 'blur(0px)', duration: 1.1, ease: 'power3.out', stagger: 0.09 },
        0.15,
      )
      ScrollTrigger.create({
        trigger: root.current,
        start: 'top 45%',
        end: 'bottom 55%',
        onEnter: () => tl.timeScale(1).play(),
        onEnterBack: () => tl.timeScale(1).play(),
        onLeave: () => tl.timeScale(2.2).reverse(),
        onLeaveBack: () => tl.timeScale(2.2).reverse(),
      })
    }, root)
    return () => ctx.revert()
  }, [])

  const right = data.side === 'right'
  return (
    <section
      id={data.id}
      ref={root}
      className={`relative flex min-h-[170vh] items-end px-5 pb-[calc(35vh+2rem)] md:items-center md:px-[7vw] md:pb-0 ${
        right ? 'md:justify-end' : 'md:justify-start'
      }`}
    >
      <div className={`w-full max-w-xl max-md:rounded-[2rem] max-md:bg-[radial-gradient(ellipse_at_center,rgba(0,0,0,0.78)_35%,transparent_75%)] max-md:py-8 md:w-[44vw] md:max-w-none ${right ? 'md:text-right' : ''}`}>
        <p className="rv mb-5 flex items-center gap-4 text-xs uppercase tracking-[0.4em] text-white/70 md:mb-7" style={right ? { justifyContent: 'flex-end' } : undefined}>
          <span className="font-display font-semibold text-white">{data.index}</span>
          <span className="h-px w-12 bg-gradient-to-r from-oil-red via-oil-violet to-oil-blue" />
          <span>{data.headline}</span>
        </p>
        <h2 className="font-display text-[clamp(2rem,4.5vw,4.8rem)] font-extrabold uppercase leading-[0.95] tracking-[-0.02em]">
          <SplitText text={data.title} />
        </h2>
        <p className={`rv mt-6 max-w-md text-pretty text-[0.95rem] leading-relaxed text-white/85 md:mt-8 md:text-lg ${right ? 'md:ml-auto' : ''}`}>
          {data.body}
        </p>
        <ul className={`rv mt-7 flex flex-wrap gap-2.5 ${right ? 'md:justify-end' : ''}`}>
          {data.tags.map((tag) => (
            <li key={tag} data-liquid className="liquid-btn cursor-default px-4 py-2 text-[0.68rem] uppercase tracking-[0.18em]">
              {tag}
            </li>
          ))}
        </ul>
        {data.id === 'interaction' ? (
          <div className={`rv mt-8 ${right ? 'md:flex md:justify-end' : ''}`}>
            <button data-liquid onClick={() => setInspect(true)} className="liquid-btn px-6 py-3.5 font-display text-xs font-semibold uppercase tracking-[0.2em]">
              Inspeccionar la forma
              <span aria-hidden>↗</span>
            </button>
          </div>
        ) : null}
      </div>
    </section>
  )
}
