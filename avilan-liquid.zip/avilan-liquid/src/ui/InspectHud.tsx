import { useEffect } from 'react'
import { useStore } from '../store/useStore'

/** Controles del modo inspeccion: la camara se acerca, el scroll se congela y el liquido se puede afinar. */
export function InspectHud() {
  const inspect = useStore((s) => s.inspect)
  const turbulence = useStore((s) => s.turbulence)
  const viscosity = useStore((s) => s.viscosity)
  const { setInspect, setTurbulence, setViscosity } = useStore.getState()

  useEffect(() => {
    if (!inspect) return
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && setInspect(false)
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [inspect, setInspect])

  return (
    <div
      aria-hidden={!inspect}
      className={`fixed inset-x-0 bottom-0 z-40 flex justify-center px-4 pb-6 transition-all duration-700 md:pb-10 ${
        inspect ? 'translate-y-0 opacity-100' : 'pointer-events-none translate-y-8 opacity-0'
      }`}
    >
      <div className="flex w-full max-w-2xl flex-col gap-5 rounded-[2rem] border border-white/20 bg-black/55 p-5 backdrop-blur-xl md:flex-row md:items-center md:gap-8 md:px-8 md:py-5">
        <p className="text-[0.62rem] uppercase leading-relaxed tracking-[0.25em] text-white/70 md:w-40">
          Arrastra para rotar. Toca para hundir. Clic para pulsar.
        </p>
        <label className="flex flex-1 flex-col gap-3 text-[0.62rem] uppercase tracking-[0.25em]">
          Turbulencia
          <input
            data-liquid
            className="liquid-range"
            type="range"
            min={0}
            max={1}
            step={0.01}
            value={turbulence}
            tabIndex={inspect ? 0 : -1}
            onChange={(e) => setTurbulence(Number(e.target.value))}
          />
        </label>
        <label className="flex flex-1 flex-col gap-3 text-[0.62rem] uppercase tracking-[0.25em]">
          Viscosidad
          <input
            data-liquid
            className="liquid-range"
            type="range"
            min={0}
            max={1}
            step={0.01}
            value={viscosity}
            tabIndex={inspect ? 0 : -1}
            onChange={(e) => setViscosity(Number(e.target.value))}
          />
        </label>
        <button data-liquid tabIndex={inspect ? 0 : -1} onClick={() => setInspect(false)} className="liquid-btn justify-center px-5 py-3 text-[0.65rem] uppercase tracking-[0.2em]">
          Salir
          <span aria-hidden>✕</span>
        </button>
      </div>
    </div>
  )
}
