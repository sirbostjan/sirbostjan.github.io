import { useEffect } from 'react'
import Lenis from 'lenis'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import { STATION_ORDER, type StationId } from '../content'
import { live, useStore } from '../store/useStore'

gsap.registerPlugin(ScrollTrigger)

let lenis: Lenis | null = null
let stops: number[] = []

/** Desplaza suavemente hasta el punto donde la camara "aterriza" en una estacion. */
export function scrollToStation(id: StationId) {
  const i = STATION_ORDER.indexOf(id)
  if (i < 0 || !lenis) return
  lenis.scrollTo(stops[i] ?? 0, { duration: 2.2, easing: (t) => 1 - Math.pow(1 - t, 4) })
}

/**
 * Lenis (scroll suave) + ScrollTrigger (UI) + mapeo scroll -> parametro de camara.
 * camT avanza de estacion en estacion con smoothstep, asi la camara se asienta
 * frente a cada objeto en lugar de pasar de largo.
 */
export function useSmoothScroll() {
  useEffect(() => {
    lenis = new Lenis({ lerp: 0.085, wheelMultiplier: 0.9, touchMultiplier: 1.4 })
    const instance = lenis
    const sections = STATION_ORDER.map((id) => document.getElementById(id))
    const last = STATION_ORDER.length - 1
    let max = 1

    const update = (y: number) => {
      live.progress = clamp(y / max, 0, 1)
      let i = 0
      while (i < last - 1 && y > stops[i + 1]) i++
      const span = Math.max(1, stops[i + 1] - stops[i])
      const frac = clamp((y - stops[i]) / span, 0, 1)
      const eased = frac * frac * (3 - 2 * frac)
      live.camT = (i + eased) / last
      useStore.getState().setSection(Math.round(i + frac))
    }

    const measure = () => {
      max = Math.max(1, document.documentElement.scrollHeight - window.innerHeight)
      stops = sections.map((el, i) => {
        if (!el || i === 0) return 0
        if (i === last) return max
        const top = el.getBoundingClientRect().top + window.scrollY
        return clamp(top + (el.offsetHeight - window.innerHeight) / 2, 0, max)
      })
      update(window.scrollY)
    }

    instance.on('scroll', (l: Lenis) => {
      live.velocity = l.velocity
      update(l.scroll)
      ScrollTrigger.update()
    })

    const raf = (time: number) => instance.raf(time * 1000)
    gsap.ticker.add(raf)
    gsap.ticker.lagSmoothing(0)

    const observer = new ResizeObserver(() => {
      measure()
      ScrollTrigger.refresh()
    })
    observer.observe(document.body)
    measure()

    // el modo inspeccion congela el scroll
    const unsubscribe = useStore.subscribe((state, prev) => {
      if (state.inspect === prev.inspect) return
      if (state.inspect) instance.stop()
      else instance.start()
    })

    return () => {
      unsubscribe()
      observer.disconnect()
      gsap.ticker.remove(raf)
      instance.destroy()
      lenis = null
    }
  }, [])
}

function clamp(v: number, a: number, b: number) {
  return Math.min(b, Math.max(a, v))
}
