import { useEffect } from 'react'
import { live, useStore } from '../store/useStore'

/**
 * Un solo listener global:
 *  - alimenta el puntero normalizado que leen camara y shaders
 *  - delega hover sobre cualquier elemento [data-liquid] (energia + onda suave)
 *  - cada clic lanza una onda en el fondo y un pulso en los objetos
 */
export function usePointer() {
  useEffect(() => {
    const { setHover, addRipple, pulse } = useStore.getState()
    let lastEl: Element | null = null

    const track = (e: PointerEvent) => {
      live.mx = e.clientX / window.innerWidth
      live.my = 1 - e.clientY / window.innerHeight
      live.px = live.mx * 2 - 1
      live.py = live.my * 2 - 1
    }

    const move = (e: PointerEvent) => {
      track(e)
      const el = e.target instanceof Element ? e.target.closest('[data-liquid]') : null
      if (el instanceof HTMLElement) {
        const r = el.getBoundingClientRect()
        el.style.setProperty('--mx', `${((e.clientX - r.left) / r.width) * 100}%`)
        el.style.setProperty('--my', `${((e.clientY - r.top) / r.height) * 100}%`)
      }
      if (el !== lastEl) {
        if (el) {
          setHover(true)
          addRipple(live.mx, live.my, 0.3)
        } else {
          setHover(false)
        }
        lastEl = el
      }
    }

    const down = (e: PointerEvent) => {
      track(e)
      addRipple(live.mx, live.my, 1)
      pulse(1)
    }

    const leave = () => {
      live.px = 0
      live.py = 0
    }

    window.addEventListener('pointermove', move, { passive: true })
    window.addEventListener('pointerdown', down, { passive: true })
    document.addEventListener('pointerleave', leave)
    return () => {
      window.removeEventListener('pointermove', move)
      window.removeEventListener('pointerdown', down)
      document.removeEventListener('pointerleave', leave)
    }
  }, [])
}
