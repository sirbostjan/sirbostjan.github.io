import { SECTIONS } from './content'
import Experience from './canvas/Experience'
import { usePointer } from './hooks/usePointer'
import { useSmoothScroll } from './hooks/useSmoothScroll'
import { useStore } from './store/useStore'
import { Contact } from './ui/Contact'
import { Cursor } from './ui/Cursor'
import { Hero } from './ui/Hero'
import { InspectHud } from './ui/InspectHud'
import { LiquidFilters } from './ui/LiquidFilters'
import { Loader } from './ui/Loader'
import { Nav } from './ui/Nav'
import { ProgressRail } from './ui/ProgressRail'
import { Section } from './ui/Section'

export default function App() {
  useSmoothScroll()
  usePointer()
  const inspect = useStore((s) => s.inspect)

  return (
    <>
      <LiquidFilters />
      <Experience />
      <Nav />
      <ProgressRail />
      <main className={`relative z-10 transition-opacity duration-700 ${inspect ? 'pointer-events-none opacity-0' : 'opacity-100'}`}>
        <Hero />
        {SECTIONS.map((section) => (
          <Section key={section.id} data={section} />
        ))}
        <Contact />
      </main>
      <InspectHud />
      <Cursor />
      <Loader />
    </>
  )
}
