import { useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import * as THREE from 'three'
import { live, useStore } from '../store/useStore'
import { Station } from './Station'
import { useLiquid } from './useLiquid'

/** Contacto: dos anillos liquidos que enmarcan el texto final. */
export function ContactRing() {
  const quality = useStore((s) => s.quality)
  const a = useRef<THREE.Mesh>(null)
  const b = useRef<THREE.Mesh>(null)
  const outer = useLiquid({ amp: 0.15, freq: 0.9, speed: 0.3, film: 2.2, glow: 0.7, seed: 21 }, 0.9)
  const inner = useLiquid({ amp: 0.07, freq: 1.4, speed: 0.45, film: 3, glow: 0.9, seed: 27 }, 0.9)
  const seg = quality === 'high' ? 320 : 160

  useFrame(() => {
    if (a.current) a.current.rotation.set(Math.sin(live.time * 0.21) * 0.3, Math.cos(live.time * 0.17) * 0.35, live.time * 0.08)
    if (b.current) b.current.rotation.set(Math.cos(live.time * 0.19) * 0.5, Math.sin(live.time * 0.23) * 0.5, -live.time * 0.12)
  })

  return (
    <Station id="contact">
      <mesh ref={a} material={outer.material}>
        <torusGeometry args={[3.3, 0.24, 48, seg]} />
      </mesh>
      <mesh ref={b} material={inner.material}>
        <torusGeometry args={[2.75, 0.07, 32, seg]} />
      </mesh>
    </Station>
  )
}
