import { useEffect, useMemo, useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import * as THREE from 'three'
import { live, useStore } from '../store/useStore'
import { Station } from './Station'
import { useLiquid } from './useLiquid'

const BEADS_PER_ORBIT = 9
const ORBITS = [
  { radius: 2.15, tilt: new THREE.Euler(0.5, 0, 0.3), speed: 0.22 },
  { radius: 2.45, tilt: new THREE.Euler(-0.9, 0.4, 0), speed: -0.17 },
  { radius: 2.75, tilt: new THREE.Euler(1.3, -0.3, 0.8), speed: 0.13 },
]
const dummy = new THREE.Object3D()
const v = new THREE.Vector3()
const tangent = new THREE.Vector3()
const q = new THREE.Quaternion()
/** ease in-out tipo curva de animacion: las cuentas aceleran y frenan como keyframes */
const ease = (x: number) => (x < 0.5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2)

/** Animation: nudo toroidal liquido + cuentas instanciadas que recorren orbitas con easing. */
export function AnimationKnot() {
  const quality = useStore((s) => s.quality)
  const knot = useRef<THREE.Mesh>(null)
  const beads = useRef<THREE.InstancedMesh>(null)
  const { material } = useLiquid({ amp: 0.12, freq: 1.25, speed: 0.4, film: 2.4, filmNoise: 1.4, glow: 0.5, seed: 4 }, 0.8)
  const bead = useLiquid({ displace: false, film: 2, glow: 1.3, seed: 6, roughness: 0.05 })
  const orbitMaterial = useMemo(
    () => new THREE.MeshBasicMaterial({ color: '#ffffff', transparent: true, opacity: 0.1, toneMapped: false }),
    [],
  )
  useEffect(() => () => orbitMaterial.dispose(), [orbitMaterial])
  const count = ORBITS.length * BEADS_PER_ORBIT

  useFrame((_, dt) => {
    if (knot.current) {
      knot.current.rotation.x += dt * 0.18
      knot.current.rotation.y += dt * 0.26
    }
    if (!beads.current) return
    let i = 0
    for (const orbit of ORBITS) {
      q.setFromEuler(orbit.tilt)
      for (let b = 0; b < BEADS_PER_ORBIT; b++) {
        const raw = live.time * Math.abs(orbit.speed) * 3 + b * 0.11
        const cycle = Math.floor(raw)
        const frac = raw - cycle
        const slot = b + (cycle + ease(frac)) * Math.sign(orbit.speed)
        const angle = (slot / BEADS_PER_ORBIT) * Math.PI * 2
        v.set(Math.cos(angle) * orbit.radius, 0, Math.sin(angle) * orbit.radius).applyQuaternion(q)
        tangent.set(-Math.sin(angle), 0, Math.cos(angle)).applyQuaternion(q)
        dummy.position.copy(v)
        // squash & stretch: se estiran mientras viajan entre keyframes
        const stretch = 1 + Math.sin(frac * Math.PI) * 1.1
        dummy.scale.set(0.07, 0.07, 0.07 * stretch)
        dummy.lookAt(v.x + tangent.x, v.y + tangent.y, v.z + tangent.z)
        dummy.updateMatrix()
        beads.current.setMatrixAt(i++, dummy.matrix)
      }
    }
    beads.current.instanceMatrix.needsUpdate = true
  })

  return (
    <Station id="animation">
      <mesh ref={knot} material={material}>
        <torusKnotGeometry args={[1.02, 0.36, quality === 'high' ? 360 : 180, quality === 'high' ? 56 : 28, 2, 3]} />
      </mesh>
      {ORBITS.map((orbit, i) => (
        <group key={i} rotation={orbit.tilt}>
          <mesh rotation-x={Math.PI / 2} material={orbitMaterial}>
            <torusGeometry args={[orbit.radius, 0.004, 6, 160]} />
          </mesh>
        </group>
      ))}
      <instancedMesh ref={beads} args={[undefined, undefined, count]} material={bead.material} frustumCulled={false}>
        <sphereGeometry args={[1, 20, 20]} />
      </instancedMesh>
    </Station>
  )
}
