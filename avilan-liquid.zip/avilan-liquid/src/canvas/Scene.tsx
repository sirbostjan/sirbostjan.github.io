import { useFrame } from '@react-three/fiber'
import * as THREE from 'three'
import { live, useStore } from '../store/useStore'
import { AnimationKnot } from './AnimationKnot'
import { AutomationCluster } from './AutomationCluster'
import { CameraRig } from './CameraRig'
import { ContactRing } from './ContactRing'
import { Droplets } from './Droplets'
import { Effects } from './Effects'
import { HeroBlob } from './HeroBlob'
import { InteractiveBlob } from './InteractiveBlob'
import { Lighting } from './Lighting'
import { LiquidBackground } from './LiquidBackground'

/** Reloj unico de la escena: avanza el tiempo y disipa impulsos antes que el resto de useFrame. */
function LiveTicker() {
  useFrame((state, dt) => {
    live.time = state.clock.elapsedTime
    live.pulse = THREE.MathUtils.damp(live.pulse, 0, 2.4, dt)
    live.energy = THREE.MathUtils.damp(live.energy, useStore.getState().hover ? 1 : 0, 3.5, dt)
  }, -1)
  return null
}

export function Scene() {
  return (
    <>
      <LiveTicker />
      <CameraRig />
      <Lighting />
      <LiquidBackground />
      <HeroBlob />
      <AnimationKnot />
      <AutomationCluster />
      <InteractiveBlob />
      <ContactRing />
      <Droplets />
      <Effects />
    </>
  )
}
