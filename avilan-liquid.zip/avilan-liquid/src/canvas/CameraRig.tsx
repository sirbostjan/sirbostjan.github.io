import { useMemo, useRef } from 'react'
import { useFrame, useThree } from '@react-three/fiber'
import * as THREE from 'three'
import { live, useStore } from '../store/useStore'
import { buildCameraPath, STATION_OBJECTS } from './stations'

const P = new THREE.Vector3()
const T = new THREE.Vector3()
const IP = new THREE.Vector3()

/** Camara sobre CatmullRomCurve3 guiada por scroll, con damping, parallax de cursor y FOV responsivo. */
export function CameraRig() {
  const size = useThree((s) => s.size)
  const portrait = size.width / size.height < 0.9
  const path = useMemo(() => buildCameraPath(portrait), [portrait])
  const s = useRef({ t: 0, px: 0, py: 0, inspect: 0, roll: 0 })

  useFrame((state, dt) => {
    const cam = state.camera as THREE.PerspectiveCamera
    const r = s.current
    const inspect = useStore.getState().inspect

    r.t = THREE.MathUtils.damp(r.t, live.camT, 2.6, dt)
    r.px = THREE.MathUtils.damp(r.px, live.px, 2.5, dt)
    r.py = THREE.MathUtils.damp(r.py, live.py, 2.5, dt)
    r.inspect = THREE.MathUtils.damp(r.inspect, inspect ? 1 : 0, 3, dt)
    r.roll = THREE.MathUtils.damp(r.roll, THREE.MathUtils.clamp(live.velocity * 0.0012, -0.06, 0.06), 4, dt)

    const t = THREE.MathUtils.clamp(r.t, 0, 1)
    live.camSmooth = t
    path.position.getPoint(t, P)
    path.target.getPoint(t, T)

    // modo inspeccion: acerca la camara y centra el objeto interactivo
    if (r.inspect > 0.001) {
      const obj = STATION_OBJECTS.interaction
      IP.set(obj.x, obj.y, obj.z + (portrait ? 6 : 4.7))
      P.lerp(IP, r.inspect)
      T.lerp(obj, r.inspect)
    }

    // parallax sutil
    const k = 1 - r.inspect * 0.6
    P.x += r.px * 0.38 * k
    P.y += r.py * 0.24 * k
    T.x += r.px * 0.08 * k

    cam.position.copy(P)
    cam.lookAt(T)
    cam.rotateZ(r.roll)

    const fov = portrait ? 58 : size.width < 1100 ? 44 : 38
    if (Math.abs(cam.fov - fov) > 0.01) {
      cam.fov = THREE.MathUtils.damp(cam.fov, fov, 6, dt)
      cam.updateProjectionMatrix()
    }
  })

  return null
}
