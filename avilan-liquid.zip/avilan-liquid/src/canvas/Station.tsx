import { useRef, type ReactNode } from 'react'
import { useFrame } from '@react-three/fiber'
import * as THREE from 'three'
import { STATION_ORDER, type StationId } from '../content'
import { live } from '../store/useStore'
import { STATION_OBJECTS } from './stations'

/**
 * Ancla un objeto en su estacion y lo hace brotar / reabsorberse segun la cercania
 * de la camara. Lo que esta lejos queda invisible y no se dibuja.
 */
export function Station({ id, children }: { id: StationId; children: ReactNode }) {
  const group = useRef<THREE.Group>(null)
  const index = STATION_ORDER.indexOf(id)

  useFrame(() => {
    if (!group.current) return
    const d = Math.abs(live.camSmooth * (STATION_ORDER.length - 1) - index)
    const k = 1 - THREE.MathUtils.smoothstep(d, 0.5, 0.95)
    group.current.visible = k > 0.001
    group.current.scale.setScalar(Math.max(k, 0.001))
  })

  return (
    <group ref={group} position={STATION_OBJECTS[id]}>
      {children}
    </group>
  )
}
