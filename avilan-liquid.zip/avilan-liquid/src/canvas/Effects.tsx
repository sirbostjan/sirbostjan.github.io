import { useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import { Bloom, ChromaticAberration, EffectComposer, N8AO, Noise, ToneMapping, Vignette } from '@react-three/postprocessing'
import { BlendFunction, ToneMappingMode, type ChromaticAberrationEffect } from 'postprocessing'
import * as THREE from 'three'
import { live, useStore } from '../store/useStore'

const OFFSET = new THREE.Vector2(0.0006, 0.0006)

export function Effects() {
  const quality = useStore((s) => s.quality)
  const chroma = useRef<ChromaticAberrationEffect>(null)

  // dispersion cromatica que respira con la velocidad de scroll y los clics
  useFrame(() => {
    if (!chroma.current) return
    const amount = 0.0006 + Math.min(Math.abs(live.velocity) * 0.00006, 0.004) + live.pulse * 0.003 + live.energy * 0.0008
    chroma.current.offset.set(amount, amount * 0.6)
  })

  return (
    <EffectComposer multisampling={0} enableNormalPass={false}>
      {quality === 'high' ? (
        <N8AO halfRes quality="medium" aoRadius={0.9} distanceFalloff={1} intensity={2.4} color="#02000a" />
      ) : (
        <></>
      )}
      <Bloom mipmapBlur intensity={0.85} luminanceThreshold={0.55} luminanceSmoothing={0.3} radius={0.78} />
      <ChromaticAberration ref={chroma} offset={OFFSET} radialModulation modulationOffset={0.18} />
      <Noise premultiply blendFunction={BlendFunction.SCREEN} opacity={0.35} />
      <Vignette offset={0.22} darkness={0.82} />
      <ToneMapping mode={ToneMappingMode.ACES_FILMIC} />
    </EffectComposer>
  )
}
