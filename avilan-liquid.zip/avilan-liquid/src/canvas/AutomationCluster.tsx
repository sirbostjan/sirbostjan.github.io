import { useEffect, useMemo, useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import * as THREE from 'three'
import { RoundedBoxGeometry } from 'three/examples/jsm/geometries/RoundedBoxGeometry.js'
import { live } from '../store/useStore'
import { Station } from './Station'
import { useLiquid } from './useLiquid'

const N = 4
const COUNT = N * N * N
const AXES = [new THREE.Vector3(1, 0, 0), new THREE.Vector3(0, 1, 0), new THREE.Vector3(0, 0, 1)]
const dummy = new THREE.Object3D()
const q = new THREE.Quaternion()
const ease = (x: number) => (x < 0.5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2)

/**
 * Automation: 64 cubos biselados (InstancedMesh) que se ordenan solos.
 * Cada ciclo, las capas giran 90 grados en cascada sobre un eje distinto, como una
 * maquina que ejecuta pasos. Tras cada giro la reticula coincide consigo misma,
 * asi que el bucle es continuo.
 */
export function AutomationCluster() {
  const group = useRef<THREE.Group>(null)
  const mesh = useRef<THREE.InstancedMesh>(null)
  const geometry = useMemo(() => new RoundedBoxGeometry(1, 1, 1, 5, 0.16), [])
  useEffect(() => () => geometry.dispose(), [geometry])
  const { material } = useLiquid({ displace: false, film: 2.2, filmNoise: 2.4, glow: 0.35, seed: 9, roughness: 0.2, metalness: 0.75, speed: 0.15 })

  useFrame((_, dt) => {
    if (group.current) {
      group.current.rotation.y += dt * 0.14
      group.current.rotation.x = 0.45 + Math.sin(live.time * 0.25) * 0.12
    }
    if (!mesh.current) return
    const t = live.time * 0.42
    const step = Math.floor(t) % 3
    const f = t - Math.floor(t)
    const axis = AXES[step]
    let i = 0
    for (let x = 0; x < N; x++)
      for (let y = 0; y < N; y++)
        for (let z = 0; z < N; z++) {
          const layer = step === 0 ? x : step === 1 ? y : z
          const k = ease(THREE.MathUtils.clamp((f - layer * 0.12) / 0.55, 0, 1))
          const open = Math.sin(k * Math.PI)
          q.setFromAxisAngle(axis, (layer % 2 ? 1 : -1) * k * Math.PI * 0.5)
          const spacing = 0.64 * (1 + open * 0.22 + live.pulse * 0.25)
          dummy.position.set((x - 1.5) * spacing, (y - 1.5) * spacing, (z - 1.5) * spacing).applyQuaternion(q)
          dummy.quaternion.copy(q)
          dummy.scale.setScalar(0.5 * (1 - open * 0.12))
          dummy.updateMatrix()
          mesh.current.setMatrixAt(i++, dummy.matrix)
        }
    mesh.current.instanceMatrix.needsUpdate = true
  })

  return (
    <Station id="automation">
      <group ref={group}>
      <instancedMesh ref={mesh} args={[geometry, material, COUNT]} castShadow receiveShadow frustumCulled={false} />
      </group>
    </Station>
  )
}
