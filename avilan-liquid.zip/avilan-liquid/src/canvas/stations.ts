import * as THREE from 'three'
import { STATION_ORDER } from '../content'

/** Posicion de cada objeto principal en el mundo. La camara viaja hacia -Z. */
export const STATION_OBJECTS: Record<(typeof STATION_ORDER)[number], THREE.Vector3> = {
  hero: new THREE.Vector3(0, 0, 0),
  animation: new THREE.Vector3(5, -0.4, -14),
  automation: new THREE.Vector3(-5, 0.4, -28),
  interaction: new THREE.Vector3(4.5, 0, -42),
  contact: new THREE.Vector3(0, 0, -58),
}

/** lado de pantalla donde queda el objeto: 1 derecha, -1 izquierda, 0 centro */
const SIDE = [0, 1, -1, 1, 0]
const DIST = [6.4, 5.8, 6.6, 5.6, 7.6]

export interface CameraPath {
  position: THREE.CatmullRomCurve3
  target: THREE.CatmullRomCurve3
}

/**
 * Construye las curvas de camara. En horizontal el objeto se desplaza a un lado para
 * dejar aire al texto; en vertical se centra arriba y la camara se aleja.
 */
export function buildCameraPath(portrait: boolean): CameraPath {
  const pos: THREE.Vector3[] = []
  const look: THREE.Vector3[] = []
  STATION_ORDER.forEach((id, i) => {
    const obj = STATION_OBJECTS[id]
    const shift = portrait ? 0 : SIDE[i] * 1.75
    const drop = portrait && SIDE[i] !== 0 ? 1.15 : 0
    const target = new THREE.Vector3(obj.x - shift, obj.y - drop, obj.z)
    const dist = DIST[i] * (portrait ? 1.25 : 1)
    look.push(target)
    pos.push(new THREE.Vector3(target.x - SIDE[i] * 0.9, target.y + 0.25, target.z + dist))
  })
  return {
    position: new THREE.CatmullRomCurve3(pos, false, 'centripetal'),
    target: new THREE.CatmullRomCurve3(look, false, 'centripetal'),
  }
}
