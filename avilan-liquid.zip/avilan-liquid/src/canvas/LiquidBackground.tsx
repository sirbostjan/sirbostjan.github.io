import { useEffect, useMemo } from 'react'
import { useFrame } from '@react-three/fiber'
import * as THREE from 'three'
import { createBackgroundMaterial } from '../shaders/backgroundMaterial'
import { live, MAX_RIPPLES, useStore } from '../store/useStore'

export function LiquidBackground() {
  const quality = useStore((s) => s.quality)
  const material = useMemo(() => createBackgroundMaterial(quality === 'high' ? 4 : 3), [quality])
  useEffect(() => () => material.dispose(), [material])

  useFrame((state, dt) => {
    const u = material.uniforms
    u.uTime.value = live.time
    u.uAspect.value = state.size.width / state.size.height
    u.uScroll.value = live.progress
    u.uEnergy.value = live.energy
    u.uPulse.value = live.pulse
    const mouse = u.uMouse.value as THREE.Vector2
    mouse.x = THREE.MathUtils.damp(mouse.x, live.mx, 3, dt)
    mouse.y = THREE.MathUtils.damp(mouse.y, live.my, 3, dt)
    const ripples = u.uRipples.value as THREE.Vector4[]
    for (let i = 0; i < MAX_RIPPLES; i++) ripples[i].fromArray(live.ripples, i * 4)
  })

  return (
    <mesh frustumCulled={false} renderOrder={-1000} material={material}>
      <planeGeometry args={[2, 2]} />
    </mesh>
  )
}
