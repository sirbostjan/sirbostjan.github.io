import { useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import * as THREE from 'three'
import { live, useStore } from '../store/useStore'
import { Station } from './Station'
import { useLiquid } from './useLiquid'

/** Gota principal: icosaedro denso deformado por fBm simplex con pelicula tornasol. */
export function HeroBlob() {
  const quality = useStore((s) => s.quality)
  const mesh = useRef<THREE.Mesh>(null)
  const { material } = useLiquid({ amp: 0.36, freq: 0.62, speed: 0.22, film: 1.9, filmNoise: 1.6, glow: 0.55, seed: 1 }, 0.5)

  useFrame((_, dt) => {
    if (!mesh.current) return
    mesh.current.rotation.y += dt * 0.12
    mesh.current.rotation.x = Math.sin(live.time * 0.2) * 0.25
    mesh.current.position.y = Math.sin(live.time * 0.6) * 0.12
    mesh.current.scale.setScalar(1 + live.pulse * 0.06)
  })

  return (
    <Station id="hero">
      <mesh ref={mesh} material={material}>
        <icosahedronGeometry args={[1.75, quality === 'high' ? 56 : 28]} />
      </mesh>
    </Station>
  )
}
