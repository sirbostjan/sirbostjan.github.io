import { useEffect, useRef } from 'react'
import { useFrame, type ThreeEvent } from '@react-three/fiber'
import * as THREE from 'three'
import { live, useStore } from '../store/useStore'
import { Station } from './Station'
import { useLiquid } from './useLiquid'

const local = new THREE.Vector3()

/**
 * 3D Interaction: gota que se hunde donde la tocas (uHit en espacio de objeto),
 * emite anillos y se puede arrastrar para rotarla con inercia.
 */
export function InteractiveBlob() {
  const quality = useStore((s) => s.quality)
  const mesh = useRef<THREE.Mesh>(null)
  const { material, uniforms } = useLiquid({ amp: 0.2, freq: 0.8, speed: 0.3, film: 2.6, filmNoise: 1.8, glow: 0.6, seed: 13 }, 0.4)
  const s = useRef({ hit: 0, hitTarget: 0, dragging: false, lastX: 0, lastY: 0, rx: 0, ry: 0, vx: 0, vy: 0.12 })

  useEffect(() => {
    const move = (e: PointerEvent) => {
      const r = s.current
      if (!r.dragging) return
      r.vy = (e.clientX - r.lastX) * 0.9
      r.vx = (e.clientY - r.lastY) * 0.9
      r.lastX = e.clientX
      r.lastY = e.clientY
    }
    const up = () => {
      s.current.dragging = false
      document.body.classList.remove('is-dragging')
    }
    window.addEventListener('pointermove', move)
    window.addEventListener('pointerup', up)
    window.addEventListener('pointercancel', up)
    return () => {
      window.removeEventListener('pointermove', move)
      window.removeEventListener('pointerup', up)
      window.removeEventListener('pointercancel', up)
      document.body.classList.remove('is-dragging')
    }
  }, [])

  const onMove = (e: ThreeEvent<PointerEvent>) => {
    if (!mesh.current) return
    local.copy(e.point)
    mesh.current.worldToLocal(local)
    uniforms.uHit.value.copy(local)
    s.current.hitTarget = 0.3
  }
  const onOver = () => useStore.getState().setHover(true)
  const onOut = () => {
    s.current.hitTarget = 0
    useStore.getState().setHover(false)
  }
  const onDown = (e: ThreeEvent<PointerEvent>) => {
    const r = s.current
    r.dragging = true
    r.lastX = e.nativeEvent.clientX
    r.lastY = e.nativeEvent.clientY
    document.body.classList.add('is-dragging')
  }

  useFrame((_, dt) => {
    const r = s.current
    const state = useStore.getState()
    r.hit = THREE.MathUtils.damp(r.hit, r.hitTarget, 6, dt)
    uniforms.uHitStrength.value = r.hit
    uniforms.uAmp.value = (0.06 + state.turbulence * 0.34) * (1 + live.energy * 0.4)
    uniforms.uSpeed.value = 0.7 - state.viscosity * 0.62

    // inercia: la velocidad decae hacia un giro lento de reposo
    if (!r.dragging) {
      r.vx = THREE.MathUtils.damp(r.vx, 0, 2.2, dt)
      r.vy = THREE.MathUtils.damp(r.vy, 0.12, 2.2, dt)
    }
    r.rx = THREE.MathUtils.clamp(r.rx + r.vx * dt, -1.2, 1.2)
    r.ry += r.vy * dt
    if (r.dragging) {
      r.vx *= 0.82
      r.vy *= 0.82
    }
    if (mesh.current) {
      mesh.current.rotation.set(r.rx, r.ry, 0)
      mesh.current.scale.setScalar(1 + live.pulse * 0.05)
    }
  })

  return (
    <Station id="interaction">
      <mesh ref={mesh} material={material}>
        <icosahedronGeometry args={[1.5, quality === 'high' ? 52 : 26]} />
      </mesh>
      {/* proxy de baja resolucion para el raycast: evita probar ~80k triangulos por evento */}
      <mesh onPointerMove={onMove} onPointerOver={onOver} onPointerOut={onOut} onPointerDown={onDown}>
        <icosahedronGeometry args={[1.62, 3]} />
        <meshBasicMaterial transparent opacity={0} depthWrite={false} colorWrite={false} />
      </mesh>
    </Station>
  )
}
