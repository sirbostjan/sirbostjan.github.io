import { useLayoutEffect, useMemo, useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import * as THREE from 'three'
import { live, useStore } from '../store/useStore'
import { useLiquid } from './useLiquid'

const dummy = new THREE.Object3D()
const Z_NEAR = 8
const Z_FAR = -70

/** Gotas en suspension a lo largo de todo el recorrido: un solo draw call con InstancedMesh. */
export function Droplets() {
  const quality = useStore((s) => s.quality)
  const count = quality === 'high' ? 520 : 220
  const mesh = useRef<THREE.InstancedMesh>(null)
  const { material } = useLiquid({ displace: false, film: 2.5, filmNoise: 3, glow: 1.1, seed: 33, roughness: 0.04, speed: 0.2 })

  const seeds = useMemo(() => {
    const data = new Float32Array(count * 6)
    for (let i = 0; i < count; i++) {
      const radius = 2.6 + Math.random() * 8
      const angle = Math.random() * Math.PI * 2
      data[i * 6] = Math.cos(angle) * radius * 1.3
      data[i * 6 + 1] = Math.sin(angle) * radius * 0.75
      data[i * 6 + 2] = THREE.MathUtils.lerp(Z_NEAR, Z_FAR, Math.random())
      data[i * 6 + 3] = 0.015 + Math.pow(Math.random(), 3) * 0.11
      data[i * 6 + 4] = Math.random() * Math.PI * 2
      data[i * 6 + 5] = 0.2 + Math.random() * 0.8
    }
    return data
  }, [count])

  useLayoutEffect(() => {
    if (mesh.current) mesh.current.instanceMatrix.setUsage(THREE.DynamicDrawUsage)
  }, [count])

  useFrame(() => {
    if (!mesh.current) return
    const t = live.time
    const boost = 1 + live.pulse * 0.6
    for (let i = 0; i < count; i++) {
      const o = i * 6
      const phase = seeds[o + 4]
      const speed = seeds[o + 5]
      // deriva lenta tipo lampara de lava, con estiramiento vertical al subir
      const wobble = Math.sin(t * 0.35 * speed + phase)
      const rise = ((t * 0.12 * speed + phase) % 1) * 3 - 1.5
      dummy.position.set(
        seeds[o] + Math.sin(t * 0.22 * speed + phase * 2) * 0.5,
        seeds[o + 1] + rise * 0.6 + wobble * 0.25,
        seeds[o + 2] + Math.cos(t * 0.18 * speed + phase) * 0.6,
      )
      const s = seeds[o + 3] * boost * (1 - Math.abs(rise) / 1.5) ** 0.35
      dummy.scale.set(s * (1 - wobble * 0.18), s * (1 + wobble * 0.3), s * (1 - wobble * 0.18))
      dummy.updateMatrix()
      mesh.current.setMatrixAt(i, dummy.matrix)
    }
    mesh.current.instanceMatrix.needsUpdate = true
  })

  return (
    <instancedMesh key={count} ref={mesh} args={[undefined, undefined, count]} material={material} frustumCulled={false}>
      <icosahedronGeometry args={[1, 3]} />
    </instancedMesh>
  )
}
