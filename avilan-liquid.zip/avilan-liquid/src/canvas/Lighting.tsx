import { useMemo, useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import { Environment, Lightformer } from '@react-three/drei'
import * as THREE from 'three'
import { live, useStore } from '../store/useStore'
import { STATION_OBJECTS } from './stations'

/** Lightformers giratorios: son los "reflectores de estudio" que ve el liquido. */
function StudioRig() {
  const group = useRef<THREE.Group>(null)
  useFrame(() => {
    if (!group.current) return
    group.current.rotation.y = live.time * 0.12 + live.progress * 4
    group.current.rotation.x = Math.sin(live.time * 0.07) * 0.35
  })
  return (
    <group ref={group}>
      <Lightformer form="rect" intensity={7} color="#ff1033" position={[-6, 1, 2]} rotation-y={Math.PI / 2} scale={[8, 5, 1]} />
      <Lightformer form="rect" intensity={7} color="#1438ff" position={[6, -1, -2]} rotation-y={-Math.PI / 2} scale={[8, 5, 1]} />
      <Lightformer form="rect" intensity={3} color="#ffffff" position={[0, 7, 0]} rotation-x={Math.PI / 2} scale={[10, 1.2, 1]} />
      <Lightformer form="ring" intensity={5} color="#b01cff" position={[0, -5, 4]} rotation-x={-Math.PI / 3} scale={3} />
      <Lightformer form="circle" intensity={4} color="#ff3b6b" position={[3, 3, 6]} scale={1.6} />
      <Lightformer form="circle" intensity={4} color="#2b6bff" position={[-3, -3, -6]} scale={1.6} />
    </group>
  )
}

export function Lighting() {
  const quality = useStore((s) => s.quality)
  const red = useRef<THREE.PointLight>(null)
  const blue = useRef<THREE.PointLight>(null)
  const auto = STATION_OBJECTS.automation
  const spotTarget = useMemo(() => new THREE.Object3D(), [])

  // dos luces que acompanan a la camara y orbitan en contrafase
  useFrame((state) => {
    const c = state.camera.position
    const a = live.time * 0.5
    red.current?.position.set(c.x + Math.cos(a) * 4, c.y + 2, c.z - 5 + Math.sin(a) * 3)
    blue.current?.position.set(c.x - Math.cos(a) * 4, c.y - 2, c.z - 5 - Math.sin(a) * 3)
  })

  return (
    <>
      <color attach="background" args={['#000000']} />
      <fogExp2 attach="fog" args={['#000000', 0.055]} />
      <Environment resolution={quality === 'high' ? 256 : 128} frames={quality === 'high' ? Infinity : 1}>
        <color attach="background" args={['#000000']} />
        <StudioRig />
      </Environment>
      <ambientLight intensity={0.15} />
      <pointLight ref={red} color="#ff1a3c" intensity={60} distance={18} decay={2} />
      <pointLight ref={blue} color="#1f4bff" intensity={60} distance={18} decay={2} />
      <primitive object={spotTarget} position={[auto.x, auto.y, auto.z]} />
      <spotLight
        position={[auto.x + 3, auto.y + 6, auto.z + 5]}
        target={spotTarget}
        angle={0.5}
        penumbra={1}
        intensity={260}
        distance={22}
        color="#ffffff"
        castShadow={quality === 'high'}
        shadow-mapSize={[1024, 1024]}
        shadow-bias={-0.0004}
        shadow-radius={6}
      />
    </>
  )
}
