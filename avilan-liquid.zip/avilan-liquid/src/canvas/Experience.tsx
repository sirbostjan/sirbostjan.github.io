import { useState } from 'react'
import { Canvas } from '@react-three/fiber'
import { PerformanceMonitor } from '@react-three/drei'
import * as THREE from 'three'
import { useStore } from '../store/useStore'
import { Scene } from './Scene'

export default function Experience() {
  const quality = useStore((s) => s.quality)
  const maxDpr = quality === 'high' ? 1.75 : 1.25
  const [dpr, setDpr] = useState(maxDpr)

  return (
    <div className="fixed inset-0 z-0">
      <Canvas
        shadows
        dpr={Math.min(dpr, maxDpr)}
        camera={{ fov: 38, near: 0.1, far: 90, position: [0, 0.25, 6.4] }}
        gl={{ antialias: false, alpha: false, powerPreference: 'high-performance', stencil: false }}
        eventSource={document.getElementById('root')!}
        eventPrefix="client"
        onCreated={({ gl }) => {
          gl.toneMapping = THREE.ACESFilmicToneMapping
          gl.setClearColor('#000000')
          // dos frames de margen para compilar shaders antes de levantar el telon
          requestAnimationFrame(() => requestAnimationFrame(() => useStore.getState().setReady()))
        }}
      >
        <PerformanceMonitor
          onDecline={() => setDpr(1)}
          onIncline={() => setDpr(maxDpr)}
          onFallback={() => useStore.getState().setQuality('low')}
        />
        <Scene />
      </Canvas>
    </div>
  )
}
