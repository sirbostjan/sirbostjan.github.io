import { useEffect, useMemo } from 'react'
import { useFrame } from '@react-three/fiber'
import { createLiquidMaterial, type LiquidOptions } from '../shaders/liquidMaterial'
import { live } from '../store/useStore'

/** Crea un material liquido, sincroniza sus uniforms con el estado vivo y lo libera al desmontar. */
export function useLiquid(options: LiquidOptions, energyBoost = 0.35) {
  // eslint-disable-next-line react-hooks/exhaustive-deps
  const liquid = useMemo(() => createLiquidMaterial(options), [])
  const baseAmp = options.amp ?? 0.25
  const baseGlow = options.glow ?? 0.5

  useEffect(() => () => liquid.material.dispose(), [liquid])

  useFrame(() => {
    const u = liquid.uniforms
    u.uTime.value = live.time
    u.uPulse.value = live.pulse
    u.uAmp.value = baseAmp * (1 + live.energy * energyBoost)
    u.uGlow.value = baseGlow * (1 + live.energy * 0.8)
  })

  return liquid
}
