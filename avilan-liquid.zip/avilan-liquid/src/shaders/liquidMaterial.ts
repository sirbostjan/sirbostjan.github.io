import * as THREE from 'three'
import { OIL_PALETTE, SIMPLEX_3D } from './glsl'

export interface LiquidOptions {
  /** desplazamiento de vertices con ruido simplex (apagar para instancias pequenas) */
  displace?: boolean
  amp?: number
  freq?: number
  speed?: number
  /** cuantas bandas tornasol recorre el Fresnel */
  film?: number
  /** cuanto aporta el ruido al grosor de la pelicula */
  filmNoise?: number
  glow?: number
  seed?: number
  roughness?: number
  metalness?: number
  clearcoat?: number
}

export interface LiquidUniforms {
  uTime: THREE.IUniform<number>
  uAmp: THREE.IUniform<number>
  uFreq: THREE.IUniform<number>
  uSpeed: THREE.IUniform<number>
  uSeed: THREE.IUniform<number>
  uFilm: THREE.IUniform<number>
  uFilmNoise: THREE.IUniform<number>
  uFilmShift: THREE.IUniform<number>
  uGlow: THREE.IUniform<number>
  uPulse: THREE.IUniform<number>
  uHit: THREE.IUniform<THREE.Vector3>
  uHitStrength: THREE.IUniform<number>
}

/**
 * MeshPhysicalMaterial extendido: conserva PBR, reflejos del Environment, niebla,
 * sombras e instancing, y le inyecta:
 *  - vertex: desplazamiento fBm simplex + normales recalculadas por diferencias finitas
 *  - fragment: Fresnel + interferencia de pelicula delgada rojo/azul (tornasol)
 */
export function createLiquidMaterial(options: LiquidOptions = {}) {
  const o = {
    displace: true,
    amp: 0.25,
    freq: 1,
    speed: 0.25,
    film: 1.6,
    filmNoise: 1.2,
    glow: 0.5,
    seed: 0,
    roughness: 0.12,
    metalness: 1,
    clearcoat: 1,
    ...options,
  }

  const uniforms: LiquidUniforms = {
    uTime: { value: 0 },
    uAmp: { value: o.amp },
    uFreq: { value: o.freq },
    uSpeed: { value: o.speed },
    uSeed: { value: o.seed },
    uFilm: { value: o.film },
    uFilmNoise: { value: o.filmNoise },
    uFilmShift: { value: o.seed * 0.137 },
    uGlow: { value: o.glow },
    uPulse: { value: 0 },
    uHit: { value: new THREE.Vector3(0, 0, 10) },
    uHitStrength: { value: 0 },
  }

  const material = new THREE.MeshPhysicalMaterial({
    color: '#0a0a0f',
    roughness: o.roughness,
    metalness: o.metalness,
    clearcoat: o.clearcoat,
    clearcoatRoughness: 0.08,
    envMapIntensity: 1.35,
  })

  material.defines = { ...material.defines, ...(o.displace ? { LQ_DISPLACE: '' } : {}) }
  material.customProgramCacheKey = () => `liquid-${o.displace ? 'd' : 's'}`

  material.onBeforeCompile = (shader) => {
    Object.assign(shader.uniforms, uniforms)

    shader.vertexShader = shader.vertexShader
      .replace(
        '#include <common>',
        /* glsl */ `#include <common>
        uniform float uTime;
        uniform float uAmp;
        uniform float uFreq;
        uniform float uSpeed;
        uniform float uSeed;
        uniform float uPulse;
        uniform vec3 uHit;
        uniform float uHitStrength;
        varying float vLqNoise;
        ${SIMPLEX_3D}
        #ifdef LQ_DISPLACE
        float lqField(vec3 p){
          float t=uTime*uSpeed;
          float n=lq_snoise(p*uFreq+vec3(0.0,t,uSeed));
          n+=0.32*lq_snoise(p*uFreq*2.03+vec3(t*1.3,uSeed,0.0));
          n+=0.09*lq_snoise(p*uFreq*4.07-vec3(0.0,0.0,t*1.7));
          vec3 d=p-uHit;
          float dist2=dot(d,d);
          float dent=-exp(-dist2*5.0)*uHitStrength;
          float ring=sin(sqrt(dist2)*9.0-uTime*6.0)*exp(-dist2*1.6)*uHitStrength*0.22;
          float shock=sin(length(p)*6.0-uTime*9.0)*uPulse*0.06;
          return n*uAmp*(1.0+uPulse*0.9)+dent+ring+shock;
        }
        #endif
        `,
      )
      .replace(
        '#include <beginnormal_vertex>',
        /* glsl */ `#include <beginnormal_vertex>
        vec3 lqN=normalize(objectNormal);
        float lqD0=0.0;
        #ifdef LQ_DISPLACE
          vec3 lqT=normalize(cross(lqN,abs(lqN.y)<0.99?vec3(0.0,1.0,0.0):vec3(1.0,0.0,0.0)));
          vec3 lqB=cross(lqN,lqT);
          const float lqE=0.012;
          lqD0=lqField(position);
          float lqD1=lqField(position+lqT*lqE);
          float lqD2=lqField(position+lqB*lqE);
          objectNormal=normalize(lqN-lqT*(lqD1-lqD0)/lqE-lqB*(lqD2-lqD0)/lqE);
          vLqNoise=lqD0/max(uAmp,0.001);
        #endif
        `,
      )
      .replace(
        '#include <begin_vertex>',
        /* glsl */ `vec3 transformed=position+lqN*lqD0;
        #ifndef LQ_DISPLACE
          vec4 lqW=vec4(position,1.0);
          #ifdef USE_INSTANCING
            lqW=instanceMatrix*lqW;
          #endif
          lqW=modelMatrix*lqW;
          vLqNoise=lq_snoise(lqW.xyz*0.45+vec3(0.0,uTime*uSpeed,uSeed));
        #endif
        `,
      )

    shader.fragmentShader = shader.fragmentShader
      .replace(
        '#include <common>',
        /* glsl */ `#include <common>
        uniform float uTime;
        uniform float uFilm;
        uniform float uFilmNoise;
        uniform float uFilmShift;
        uniform float uGlow;
        uniform float uPulse;
        varying float vLqNoise;
        vec3 lqIri=vec3(0.0);
        float lqFres=0.0;
        ${OIL_PALETTE}
        `,
      )
      .replace(
        '#include <normal_fragment_maps>',
        /* glsl */ `#include <normal_fragment_maps>
        lqFres=pow(1.0-clamp(abs(dot(normal,normalize(vViewPosition))),0.0,1.0),1.5);
        float lqThick=lqFres*uFilm+vLqNoise*uFilmNoise*0.35+uTime*0.035+uFilmShift+uPulse*0.35;
        lqIri=lq_oil(lqThick);
        diffuseColor.rgb=mix(vec3(0.015),lqIri,0.45+0.55*lqFres);
        `,
      )
      .replace(
        '#include <emissivemap_fragment>',
        /* glsl */ `#include <emissivemap_fragment>
        totalEmissiveRadiance+=lqIri*(0.06+lqFres)*(uGlow+uPulse*1.4);
        `,
      )
  }

  return { material, uniforms }
}
