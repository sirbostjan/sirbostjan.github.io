import * as THREE from 'three'
import { OIL_PALETTE, SIMPLEX_3D } from './glsl'
import { MAX_RIPPLES } from '../store/useStore'

/** Fondo fluido a pantalla completa: fBm con domain warping, remolino del cursor y ondas de clic. */
export function createBackgroundMaterial(octaves: number) {
  return new THREE.ShaderMaterial({
    depthTest: false,
    depthWrite: false,
    fog: false,
    toneMapped: false,
    defines: { OCTAVES: octaves, MAX_RIPPLES },
    uniforms: {
      uTime: { value: 0 },
      uAspect: { value: 1 },
      uMouse: { value: new THREE.Vector2(0.5, 0.5) },
      uScroll: { value: 0 },
      uEnergy: { value: 0 },
      uPulse: { value: 0 },
      uRipples: { value: Array.from({ length: MAX_RIPPLES }, () => new THREE.Vector4(0, 0, -100, 0)) },
    },
    vertexShader: /* glsl */ `
      varying vec2 vUv;
      void main(){
        vUv=uv;
        gl_Position=vec4(position.xy,1.0,1.0);
      }
    `,
    fragmentShader: /* glsl */ `
      precision highp float;
      uniform float uTime;
      uniform float uAspect;
      uniform vec2 uMouse;
      uniform float uScroll;
      uniform float uEnergy;
      uniform float uPulse;
      uniform vec4 uRipples[MAX_RIPPLES];
      varying vec2 vUv;
      ${SIMPLEX_3D}
      ${OIL_PALETTE}

      float fbm(vec3 p){
        float a=0.5;
        float s=0.0;
        for(int i=0;i<OCTAVES;i++){
          s+=a*lq_snoise(p);
          p=p*2.02+vec3(13.1,7.7,3.3);
          a*=0.5;
        }
        return s;
      }

      void main(){
        vec2 asp=vec2(uAspect,1.0);
        vec2 p=(vUv-0.5)*asp;
        vec2 m=(uMouse-0.5)*asp;
        float t=uTime*0.05;

        // ondas de clic: anillo que viaja y refracta el dominio
        float rip=0.0;
        for(int i=0;i<MAX_RIPPLES;i++){
          vec4 r=uRipples[i];
          float age=uTime-r.z;
          if(age>0.0&&age<5.0){
            vec2 d=p-(r.xy-0.5)*asp;
            float dist=length(d);
            float front=dist-age*0.5;
            float w=sin(front*30.0)*exp(-front*front*22.0)*exp(-age*0.9)*r.w;
            rip+=w;
            p+=normalize(d+1e-4)*w*0.045;
          }
        }

        // remolino viscoso alrededor del cursor
        vec2 dm=p-m;
        float mInf=exp(-dot(dm,dm)*6.0);
        p+=vec2(-dm.y,dm.x)*mInf*(0.45+uEnergy*0.5);

        vec2 s=p*1.2;
        float z=t+uScroll*0.8;
        vec2 q=vec2(fbm(vec3(s,z)),fbm(vec3(s+vec2(5.2,1.3),z+2.8)));
        vec2 r=vec2(
          fbm(vec3(s+3.0*q+vec2(1.7,9.2),z*1.3)),
          fbm(vec3(s+3.0*q+vec2(8.3,2.8),z*1.3)));
        float f=fbm(vec3(s+3.2*r,z*0.8));

        float thick=f*1.7+length(r)*1.4+uScroll*2.0+rip*0.9+mInf*0.5+uPulse*0.3;
        vec3 col=lq_oil(thick);

        // la mayor parte queda en negro: solo vetas y charcos tornasol
        float mask=smoothstep(0.1,0.95,f*0.5+0.5)*(0.2+0.8*smoothstep(0.1,0.9,length(q)));
        mask=pow(mask,1.8);
        float bands=0.75+0.25*sin(thick*18.0);
        col*=mask*bands*(0.42+uEnergy*0.35+uPulse*0.4)*mix(0.6,1.0,smoothstep(0.6,1.4,uAspect));
        col+=lq_oil(thick+0.25)*(mInf*0.10+abs(rip)*0.9);

        // caida a negro en los bordes para proteger el texto
        col*=smoothstep(1.35,0.15,length(p*vec2(0.75,1.0)));
        gl_FragColor=vec4(col,1.0);
      }
    `,
  })
}
