/** Todo el contenido editable del sitio vive aqui. */
export const PROFILE = {
  name: 'Juan Sebastian Avilan',
  initials: 'JSA',
  role: 'Ingeniero en Multimedia',
  tagline: 'Motion, automatización y experiencias 3D que se sienten vivas.',
  location: 'Colombia · Remoto',
}

/** Deja un campo vacio para ocultarlo. `email` activa el boton principal de contacto. */
export const CONTACT: { email: string; links: { label: string; href: string }[] } = {
  email: '',
  links: [],
}

export type StationId = 'hero' | 'animation' | 'automation' | 'interaction' | 'contact'

export const SECTIONS: {
  id: Exclude<StationId, 'hero' | 'contact'>
  index: string
  title: string
  headline: string
  body: string
  tags: string[]
  side: 'left' | 'right'
}[] = [
  {
    id: 'animation',
    index: '01',
    title: 'Animation',
    headline: 'El movimiento como lenguaje.',
    body: 'Motion graphics, animación 3D y edición con ritmo. Piezas que guían la mirada cuadro a cuadro y convierten una idea en algo que se siente en el cuerpo.',
    tags: ['Motion graphics', 'Animación 3D', 'Edición y color', 'Video con IA'],
    side: 'left',
  },
  {
    id: 'automation',
    index: '02',
    title: 'Automation',
    headline: 'Procesos que trabajan solos.',
    body: 'Pipelines que conectan guion, voz, material y montaje para producir más sin perder el pulso creativo. Menos clics repetidos, más tiempo para diseñar.',
    tags: ['Pipelines de video', 'Scripts en Python', 'Flujos con IA', 'Entrega sin fricción'],
    side: 'right',
  },
  {
    id: 'interaction',
    index: '03',
    title: '3D Interaction',
    headline: 'Mundos que responden.',
    body: 'WebGL, shaders y escenas en tiempo real que reaccionan a cada gesto. Toca la forma, arrástrala, haz clic y mira cómo el líquido te contesta.',
    tags: ['WebGL · Three.js', 'Shaders GLSL', 'Tiempo real', 'Experiencias web'],
    side: 'left',
  },
]

export const STATION_ORDER: StationId[] = ['hero', 'animation', 'automation', 'interaction', 'contact']
export const STATION_LABELS: Record<StationId, string> = {
  hero: 'Inicio',
  animation: 'Animation',
  automation: 'Automation',
  interaction: '3D Interaction',
  contact: 'Contacto',
}
