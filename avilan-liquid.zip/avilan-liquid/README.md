# Juan Sebastian Avilan · Liquid Portfolio

Experiencia web 3D con líquidos tornasol rojo/azul. React 19 + Vite + TypeScript + Tailwind 4, Three.js + React Three Fiber + drei, postprocessing, GSAP ScrollTrigger + Lenis y Zustand.

## Uso

```bash
npm install
npm run dev      # desarrollo en http://localhost:5173
npm run build    # typecheck + build de producción en dist/
npm run preview  # sirve dist/
```

## Dónde tocar

- `src/content.ts`: nombre, textos de las secciones, email y redes (el botón de email aparece al llenar `CONTACT.email`).
- `src/shaders/glsl.ts`: `lq_oil()` es la paleta tornasol; ahí se cambian los colores de todo el sitio.
- `src/shaders/liquidMaterial.ts`: material líquido (desplazamiento simplex + película delgada sobre MeshPhysicalMaterial).
- `src/shaders/backgroundMaterial.ts`: fondo fluido, remolino del cursor y ondas de clic.
- `src/canvas/stations.ts`: posición de cada objeto y recorrido de cámara (CatmullRomCurve3).
- `src/canvas/*`: un componente por objeto (HeroBlob, AnimationKnot, AutomationCluster, InteractiveBlob, ContactRing, Droplets).
- `src/store/useStore.ts`: estado compartido DOM/Canvas. `live` es mutable y se lee por frame sin re-renders.

## Interacciones

- Scroll: la cámara viaja entre estaciones y se asienta frente a cada objeto.
- Cursor: parallax de cámara, remolino en el fondo, hover en cualquier `[data-liquid]` energiza los shaders.
- Clic: onda en el fondo + pulso en todos los objetos + dispersión cromática.
- 3D Interaction: toca la gota para hundirla, arrástrala para rotarla, "Inspeccionar la forma" abre controles de turbulencia y viscosidad (Esc para salir).
